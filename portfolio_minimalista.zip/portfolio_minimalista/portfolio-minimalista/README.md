# portfolio-minimalista

Portfólio minimalista desenvolvido com HTML, CSS/SASS e JavaScript

[Run here](https://rodrigocloureiro.github.io/portfolio-minimalista/)
